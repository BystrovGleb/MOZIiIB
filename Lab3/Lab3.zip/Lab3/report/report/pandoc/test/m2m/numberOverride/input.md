---
numberSections: true
sectionsDepth: -1
chaptersDepth: 3
chapters: true
...

# Section

## Earlier Subsection

![Image 1](img2.png){#fig:img1}

## Title of Subsection {number=6}

![Image 1.6.2](img2.png){#fig:img2}

![Image 1.6.100500](img2.png){#fig:img3 number=100500}

![Image 1.6.100501](img2.png){#fig:img4}

## Title of Subsection

![Image 1.7.1](img2.png){#fig:img21}

![Image 1.7.100500](img2.png){#fig:img31 number=100500}

![Image 1.7.100501](img2.png){#fig:img41}
