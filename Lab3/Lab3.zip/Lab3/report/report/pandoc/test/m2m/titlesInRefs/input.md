---
refIndexTemplate:
  sec: $$i$$$$suf$$ ($$t$$)
  default: $$i$$$$suf$$
---

# Section {#sec:section}

![A Figure](figure.png){#fig:figure}

[@sec:section]

[@fig:figure]
