![Figure 1: 1](fig1.png){#fig:1}

![Figure 2: 2](fig2.png){#fig:2}

![Figure 3: 3](fig3.png){#fig:3}

![Figure 4: 4](fig4.png){#fig:4}

![Figure 5: 5](fig5.png){#fig:5}

![Figure 6: 6](fig6.png){#fig:6}

![Figure 7: 7](fig7.png){#fig:7}

![Figure 8: 8](fig8.png){#fig:8}

![Figure 9: 9](fig9.png){#fig:9}

# List of Figures

::: {.list .list-of-fig}
-   1: 1
-   2: 2
-   3: 3
-   4: 4
-   5: 5
-   6: 6
-   7: 7
-   8: 8
-   9: 9
:::
