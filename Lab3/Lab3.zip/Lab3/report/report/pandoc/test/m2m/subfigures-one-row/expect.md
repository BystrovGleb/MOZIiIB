# Figures

Regression test for
[#381](https://github.com/lierdakil/pandoc-crossref/issues/381)

:::: {#fig:latex .figure .subfigures}
![a](/tmp/LaTeX_logo.svg.png){#fig:logo1 width="40%"}
![b](/tmp/LaTeX_logo.svg.png){#fig:logo2 width="40%"}

::: caption
Figure 1: Copies of the LaTeX logo. a --- cool caption, b --- cooler
caption
:::
::::

Those logos are different I swear. Especially fig. 1 (a) and fig. 1 (b).
