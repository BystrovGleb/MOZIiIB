---
codeBlockCaptions: true
listings: true
...

This is #278 regression test

```{#lst:some_listing}
```

Listing: some_listing
