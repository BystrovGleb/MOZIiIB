# 1 Section

## 1.1 Earlier Subsection

![Figure 1.1.1: Image 1](img2.png){#fig:img1}

## 1.6 Title of Subsection {#title-of-subsection number="6"}

![Figure 1.6.1: Image 1.6.2](img2.png){#fig:img2}

![Figure 1.6.100500: Image 1.6.100500](img2.png){#fig:img3
number="100500"}

![Figure 1.6.100501: Image 1.6.100501](img2.png){#fig:img4}

## 1.7 Title of Subsection

![Figure 1.7.1: Image 1.7.1](img2.png){#fig:img21}

![Figure 1.7.100500: Image 1.7.100500](img2.png){#fig:img31
number="100500"}

![Figure 1.7.100501: Image 1.7.100501](img2.png){#fig:img41}
