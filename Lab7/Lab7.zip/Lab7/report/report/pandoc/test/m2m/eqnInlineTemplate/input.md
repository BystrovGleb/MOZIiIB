---
eqnInlineTemplate: |
  \\begin{array}{lr}
  $$e$$ & $$i$$
  \\end{array}
---

$$\int_0^x e^x dx$${#eq:1}
