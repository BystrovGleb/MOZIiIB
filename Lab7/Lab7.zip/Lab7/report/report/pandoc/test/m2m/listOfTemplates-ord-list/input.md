---
lofItemTemplate: |
  1. $$t$$
---

![1](fig1.png){#fig:1}

![2](fig2.png){#fig:2}

![3](fig3.png){#fig:3}

![4](fig4.png){#fig:4}

![5](fig5.png){#fig:5}

![6](fig6.png){#fig:6}

![7](fig7.png){#fig:7}

![8](fig8.png){#fig:8}

![9](fig9.png){#fig:9}


\listoffigures
