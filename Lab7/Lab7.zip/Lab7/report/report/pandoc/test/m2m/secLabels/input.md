---
numberSections: true
sectionsDepth: -1
secLabels: alpha a
figLabels: alpha a
tblLabels: roman
---

# First Level Section

## Second Level Section

![my figure](myfig.png){#fig:myfig}

## Other Second Level Section

a   b   c
--- --- ---
1   2   3
4   5   6

: My table {#tbl:mytable}
