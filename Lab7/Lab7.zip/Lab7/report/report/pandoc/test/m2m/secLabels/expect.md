# a First Level Section {#first-level-section}

## a.a Second Level Section {#second-level-section}

![Figure a: my figure](myfig.png){#fig:myfig}

## a.b Other Second Level Section {#other-second-level-section}

::: {#tbl:mytable}
  a   b   c
  --- --- ---
  1   2   3
  4   5   6

  : Table I: My table
:::
