::: {#eq:1}
[$$\int_0^x e^x dx$$]{.math-eq}
[$$\int_0^x e^x dx$$]{.math-eq-backwards-compat}
[$$(1)$$]{.math-eq-index-math} [(1)]{.math-eq-index-no-math}
[$$1$$]{.math-eq-index-raw-math} [1]{.math-eq-index-raw-no-math}
:::
