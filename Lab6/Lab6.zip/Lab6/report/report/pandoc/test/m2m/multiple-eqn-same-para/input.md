Simple test
$$x=y$${#eq:1}
$$x=y$${#eq:2}

[@eq:1; @eq:2]
