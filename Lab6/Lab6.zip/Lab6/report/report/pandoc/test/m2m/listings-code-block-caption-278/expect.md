This is #278 regression test

::: {#lst:some_listing .listing}
Listing 1: some_listing
:::
