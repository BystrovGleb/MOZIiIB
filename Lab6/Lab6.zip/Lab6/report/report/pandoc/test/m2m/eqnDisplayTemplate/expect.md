[[ [$$e^{i\pi} = -1\qquad{(1)}$$]{.math-eq}
[$$(1)$$]{.math-eq-index-math} [(1)]{.math-eq-index-no-math}
[$$1$$]{.math-eq-index-raw-math} [1]{.math-eq-index-raw-no-math}
]{.math-eq-container}]{#eq:euler}

eq. 1
