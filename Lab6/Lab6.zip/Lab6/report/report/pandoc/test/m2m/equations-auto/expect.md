This is a test file with some referenced equations, line
$$ this \qquad{(1)}$$

Some equations might be inside of text, $$ for example \qquad{(2)}$$
this one.

Some equations might be on start of paragraphs:

$$ start \qquad{(3)}$$ of paragraph.

Other might be on separate paragraphs of their own:

$$ separate \qquad{(4)}$$

Some of those can be labelled:

This is a test file with some referenced equations, line
[$$ this \qquad{(5)}$$]{#eq:0}

Some equations might be inside of text,
[$$ for example \qquad{(6)}$$]{#eq:1} this one.

Some equations might be on start of paragraphs:

[$$ start \qquad{(7)}$$]{#eq:2} of paragraph.

Other might be on separate paragraphs of their own:

[$$ separate \qquad{(8)}$$]{#eq:3}

Then they can be referenced:

Individually eq. 5, eq. 6, eq. 7, eq. 8

Or in groups eqns. 5, 6, 8

Groups will be compacted eqns. 5-8
