---
codeBlockCaptions: true
...

After code block

```haskell
main :: IO ()
main = putStrLn "Hello World!"
```
: Listing caption 1 {#lst:code1}

```haskell
main :: IO ()
main = putStrLn "Hello World!"
```

: Listing caption 2 {#lst:code2}

```{#lst:code3 .haskell}
main :: IO ()
main = putStrLn "Hello World!"
```
: Listing caption 3

```{#lst:code4 .haskell}
main :: IO ()
main = putStrLn "Hello World!"
```

: Listing caption 4

```haskell
main :: IO ()
main = putStrLn "Hello World!"
```
: Listing caption 5 (invalid)

```haskell
main :: IO ()
main = putStrLn "Hello World!"
```

: Listing caption 6 (invalid)

Before code block


: Listing caption 11 {#lst:code11}
```haskell
main :: IO ()
main = putStrLn "Hello World!"
```

: Listing caption 12 {#lst:code12}

```haskell
main :: IO ()
main = putStrLn "Hello World!"
```

: Listing caption 13
```{#lst:code13 .haskell}
main :: IO ()
main = putStrLn "Hello World!"
```

: Listing caption 14

```{#lst:code14 .haskell}
main :: IO ()
main = putStrLn "Hello World!"
```

---

: Listing caption 15 (invalid)
```haskell
main :: IO ()
main = putStrLn "Hello World!"
```

: Listing caption 16 (invalid)

```haskell
main :: IO ()
main = putStrLn "Hello World!"
```


@lst:code1

@lst:code2

@lst:code3

@lst:code4

@lst:code11

@lst:code12

@lst:code13

@lst:code14
