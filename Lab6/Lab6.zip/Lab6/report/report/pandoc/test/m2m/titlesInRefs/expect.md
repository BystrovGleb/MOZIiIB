# Section {#sec:section}

![Figure 1: A Figure](figure.png){#fig:figure}

sec. 1 (Section)

fig. 1
