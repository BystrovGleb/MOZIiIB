# Figures

Regression test for [#381](https://github.com/lierdakil/pandoc-crossref/issues/381)

<div id="fig:latex">
![cool caption](/tmp/LaTeX_logo.svg.png){#fig:logo1 width=40%}
![cooler caption](/tmp/LaTeX_logo.svg.png){#fig:logo2 width=40%}

Copies of the LaTeX logo
</div>

Those logos are different I swear. Especially [@fig:logo1] and [@fig:logo2].
