Simple test [$$x=y\qquad{(1)}$$]{#eq:1} [$$x=y\qquad{(2)}$$]{#eq:2}

eqns. 1, 2
