[$$\begin{array}{lr} \int_0^x e^x dx & (1) \end{array}$$]{#eq:1}
