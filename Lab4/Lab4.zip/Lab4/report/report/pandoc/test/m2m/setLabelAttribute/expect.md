# Section {#section label="1"}

:::: {#fig:1 .figure label="1.1"}
![Figure 1.1: Figure](./image.png)

::: caption
Figure 1.1: Figure
:::
::::

[$$equation\qquad{(1.1)}$$]{#eq:1 label="(1.1)"}

::: {#tbl:1 label="1.1"}
  a   b
  --- ---
  1   2

  : Table 1.1: Table
:::

::: {#lst:1 .listing}
Listing 1.1: Code Listing

``` {label="1.1"}
code
```
:::

## Section {#section-1 label="1.customLabel"}

fig. 1.1

eq. 1.1

tbl. 1.1

lst. 1.1
