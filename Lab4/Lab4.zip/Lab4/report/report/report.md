---
## Front matter
title: "Отчёт по лабораторной работе №4"
subtitle: "Простейший вариант"
author: "<Быстров Глеб Андреевич>"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
lot: true # List of tables
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: IBM Plex Serif
romanfont: IBM Plex Serif
sansfont: IBM Plex Sans
monofont: IBM Plex Mono
mathfont: STIX Two Math
mainfontoptions: Ligatures=Common,Ligatures=TeX,Scale=0.94
romanfontoptions: Ligatures=Common,Ligatures=TeX,Scale=0.94
sansfontoptions: Ligatures=Common,Ligatures=TeX,Scale=MatchLowercase,Scale=0.94
monofontoptions: Scale=MatchLowercase,Scale=0.94,FakeStretch=0.9
mathfontoptions:
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Рис."
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lotTitle: "Список таблиц"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

Получить понимание как вычислять наибольший общий делитель.

# Задание

Реализовать алгоритмы Евклида.

# Теоретическое введение

Алгори́тм Евкли́да — эффективный алгоритм для нахождения наибольшего общего делителя двух целых чисел (или общей меры двух отрезков). 

Для нахождения наибольшего общего делителя двух чисел нужно заменить большее из чисел на остаток от деления его на меньшее и для полученной пары повторять эту процедуру, пока одно из чисел не станет равно нулю. Тогда второе число будет равно наибольшему общему делителю исходных чисел. 

Например, НОД(175,90)=НОД(85,90)=НОД(85,5)=НОД(0,5)=5

# Выполнение лабораторной работы

1. Реализовал алгоритм Евклида (рис. [-@fig:001]).

![Код](image/1.png){#fig:001 width=70%}

2. Реализовал бинарный алгоритм Евклида (рис. [-@fig:002]).

![Код](image/2.png){#fig:002 width=70%}

3. Реализовал расширенный алгоритм Евклида (рис. [-@fig:003]).

![Код](image/3.png){#fig:003 width=70%}

4. Реализовал  расширенный бинарный алгоритм Евклида (рис. [-@fig:004]).

![Код](image/4.png){#fig:004 width=70%}

5. Результаты работы алгоритмов Евклида (рис. [-@fig:005]).

![Код с выводом](image/5.png){#fig:005 width=70%}

# Выводы

Успешно удалось получить понимание как работает вычисление наибольшего общего делителя и реализовать на практике алгоритмы Евклида.

# Список литературы{.unnumbered}

::: {#refs}
:::
